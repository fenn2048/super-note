import { g as getConfig, i as isConfigured } from "./chunks/storage-DiurM1t3.js";
import { i as importNote, N as NowenApiError } from "./chunks/api-BSyEg_1v.js";
function extend(destination) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i];
    for (var key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) destination[key] = source[key];
    }
  }
  return destination;
}
function repeat(character, count) {
  return Array(count + 1).join(character);
}
function trimLeadingNewlines(string) {
  return string.replace(/^\n*/, "");
}
function trimTrailingNewlines(string) {
  var indexEnd = string.length;
  while (indexEnd > 0 && string[indexEnd - 1] === "\n") indexEnd--;
  return string.substring(0, indexEnd);
}
function trimNewlines(string) {
  return trimTrailingNewlines(trimLeadingNewlines(string));
}
var blockElements = ["ADDRESS", "ARTICLE", "ASIDE", "AUDIO", "BLOCKQUOTE", "BODY", "CANVAS", "CENTER", "DD", "DIR", "DIV", "DL", "DT", "FIELDSET", "FIGCAPTION", "FIGURE", "FOOTER", "FORM", "FRAMESET", "H1", "H2", "H3", "H4", "H5", "H6", "HEADER", "HGROUP", "HR", "HTML", "ISINDEX", "LI", "MAIN", "MENU", "NAV", "NOFRAMES", "NOSCRIPT", "OL", "OUTPUT", "P", "PRE", "SECTION", "TABLE", "TBODY", "TD", "TFOOT", "TH", "THEAD", "TR", "UL"];
function isBlock(node) {
  return is(node, blockElements);
}
var voidElements = ["AREA", "BASE", "BR", "COL", "COMMAND", "EMBED", "HR", "IMG", "INPUT", "KEYGEN", "LINK", "META", "PARAM", "SOURCE", "TRACK", "WBR"];
function isVoid(node) {
  return is(node, voidElements);
}
function hasVoid(node) {
  return has(node, voidElements);
}
var meaningfulWhenBlankElements = ["A", "TABLE", "THEAD", "TBODY", "TFOOT", "TH", "TD", "IFRAME", "SCRIPT", "AUDIO", "VIDEO"];
function isMeaningfulWhenBlank(node) {
  return is(node, meaningfulWhenBlankElements);
}
function hasMeaningfulWhenBlank(node) {
  return has(node, meaningfulWhenBlankElements);
}
function is(node, tagNames) {
  return tagNames.indexOf(node.nodeName) >= 0;
}
function has(node, tagNames) {
  return node.getElementsByTagName && tagNames.some(function(tagName) {
    return node.getElementsByTagName(tagName).length;
  });
}
var markdownEscapes = [[/\\/g, "\\\\"], [/\*/g, "\\*"], [/^-/g, "\\-"], [/^\+ /g, "\\+ "], [/^(=+)/g, "\\$1"], [/^(#{1,6}) /g, "\\$1 "], [/`/g, "\\`"], [/^~~~/g, "\\~~~"], [/\[/g, "\\["], [/\]/g, "\\]"], [/^>/g, "\\>"], [/_/g, "\\_"], [/^(\d+)\. /g, "$1\\. "]];
function escapeMarkdown(string) {
  return markdownEscapes.reduce(function(accumulator, escape) {
    return accumulator.replace(escape[0], escape[1]);
  }, string);
}
var rules$1 = {};
rules$1.paragraph = {
  filter: "p",
  replacement: function(content) {
    return "\n\n" + content + "\n\n";
  }
};
rules$1.lineBreak = {
  filter: "br",
  replacement: function(content, node, options) {
    return options.br + "\n";
  }
};
rules$1.heading = {
  filter: ["h1", "h2", "h3", "h4", "h5", "h6"],
  replacement: function(content, node, options) {
    var hLevel = Number(node.nodeName.charAt(1));
    if (options.headingStyle === "setext" && hLevel < 3) {
      var underline = repeat(hLevel === 1 ? "=" : "-", content.length);
      return "\n\n" + content + "\n" + underline + "\n\n";
    } else {
      return "\n\n" + repeat("#", hLevel) + " " + content + "\n\n";
    }
  }
};
rules$1.blockquote = {
  filter: "blockquote",
  replacement: function(content) {
    content = trimNewlines(content).replace(/^/gm, "> ");
    return "\n\n" + content + "\n\n";
  }
};
rules$1.list = {
  filter: ["ul", "ol"],
  replacement: function(content, node) {
    var parent = node.parentNode;
    if (parent.nodeName === "LI" && parent.lastElementChild === node) {
      return "\n" + content;
    } else {
      return "\n\n" + content + "\n\n";
    }
  }
};
rules$1.listItem = {
  filter: "li",
  replacement: function(content, node, options) {
    var prefix = options.bulletListMarker + "   ";
    var parent = node.parentNode;
    if (parent.nodeName === "OL") {
      var start = parent.getAttribute("start");
      var index = Array.prototype.indexOf.call(parent.children, node);
      prefix = (start ? Number(start) + index : index + 1) + ".  ";
    }
    var isParagraph = /\n$/.test(content);
    content = trimNewlines(content) + (isParagraph ? "\n" : "");
    content = content.replace(/\n/gm, "\n" + " ".repeat(prefix.length));
    return prefix + content + (node.nextSibling ? "\n" : "");
  }
};
rules$1.indentedCodeBlock = {
  filter: function(node, options) {
    return options.codeBlockStyle === "indented" && node.nodeName === "PRE" && node.firstChild && node.firstChild.nodeName === "CODE";
  },
  replacement: function(content, node, options) {
    return "\n\n    " + node.firstChild.textContent.replace(/\n/g, "\n    ") + "\n\n";
  }
};
rules$1.fencedCodeBlock = {
  filter: function(node, options) {
    return options.codeBlockStyle === "fenced" && node.nodeName === "PRE" && node.firstChild && node.firstChild.nodeName === "CODE";
  },
  replacement: function(content, node, options) {
    var className = node.firstChild.getAttribute("class") || "";
    var language = (className.match(/language-(\S+)/) || [null, ""])[1];
    var code = node.firstChild.textContent;
    var fenceChar = options.fence.charAt(0);
    var fenceSize = 3;
    var fenceInCodeRegex = new RegExp("^" + fenceChar + "{3,}", "gm");
    var match;
    while (match = fenceInCodeRegex.exec(code)) {
      if (match[0].length >= fenceSize) {
        fenceSize = match[0].length + 1;
      }
    }
    var fence = repeat(fenceChar, fenceSize);
    return "\n\n" + fence + language + "\n" + code.replace(/\n$/, "") + "\n" + fence + "\n\n";
  }
};
rules$1.horizontalRule = {
  filter: "hr",
  replacement: function(content, node, options) {
    return "\n\n" + options.hr + "\n\n";
  }
};
rules$1.inlineLink = {
  filter: function(node, options) {
    return options.linkStyle === "inlined" && node.nodeName === "A" && node.getAttribute("href");
  },
  replacement: function(content, node) {
    var href = escapeLinkDestination(node.getAttribute("href"));
    var title = escapeLinkTitle(cleanAttribute(node.getAttribute("title")));
    var titlePart = title ? ' "' + title + '"' : "";
    return "[" + content + "](" + href + titlePart + ")";
  }
};
rules$1.referenceLink = {
  filter: function(node, options) {
    return options.linkStyle === "referenced" && node.nodeName === "A" && node.getAttribute("href");
  },
  replacement: function(content, node, options) {
    var href = escapeLinkDestination(node.getAttribute("href"));
    var title = cleanAttribute(node.getAttribute("title"));
    if (title) title = ' "' + escapeLinkTitle(title) + '"';
    var replacement;
    var reference;
    switch (options.linkReferenceStyle) {
      case "collapsed":
        replacement = "[" + content + "][]";
        reference = "[" + content + "]: " + href + title;
        break;
      case "shortcut":
        replacement = "[" + content + "]";
        reference = "[" + content + "]: " + href + title;
        break;
      default:
        var id = this.references.length + 1;
        replacement = "[" + content + "][" + id + "]";
        reference = "[" + id + "]: " + href + title;
    }
    this.references.push(reference);
    return replacement;
  },
  references: [],
  append: function(options) {
    var references = "";
    if (this.references.length) {
      references = "\n\n" + this.references.join("\n") + "\n\n";
      this.references = [];
    }
    return references;
  }
};
rules$1.emphasis = {
  filter: ["em", "i"],
  replacement: function(content, node, options) {
    if (!content.trim()) return "";
    return options.emDelimiter + content + options.emDelimiter;
  }
};
rules$1.strong = {
  filter: ["strong", "b"],
  replacement: function(content, node, options) {
    if (!content.trim()) return "";
    return options.strongDelimiter + content + options.strongDelimiter;
  }
};
rules$1.code = {
  filter: function(node) {
    var hasSiblings = node.previousSibling || node.nextSibling;
    var isCodeBlock = node.parentNode.nodeName === "PRE" && !hasSiblings;
    return node.nodeName === "CODE" && !isCodeBlock;
  },
  replacement: function(content) {
    if (!content) return "";
    content = content.replace(/\r?\n|\r/g, " ");
    var extraSpace = /^`|^ .*?[^ ].* $|`$/.test(content) ? " " : "";
    var delimiter = "`";
    var matches = content.match(/`+/gm) || [];
    while (matches.indexOf(delimiter) !== -1) delimiter = delimiter + "`";
    return delimiter + extraSpace + content + extraSpace + delimiter;
  }
};
rules$1.image = {
  filter: "img",
  replacement: function(content, node) {
    var alt = escapeMarkdown(cleanAttribute(node.getAttribute("alt")));
    var src = escapeLinkDestination(node.getAttribute("src") || "");
    var title = cleanAttribute(node.getAttribute("title"));
    var titlePart = title ? ' "' + escapeLinkTitle(title) + '"' : "";
    return src ? "![" + alt + "](" + src + titlePart + ")" : "";
  }
};
function cleanAttribute(attribute) {
  return attribute ? attribute.replace(/(\n+\s*)+/g, "\n") : "";
}
function escapeLinkDestination(destination) {
  var escaped = destination.replace(/([<>()])/g, "\\$1");
  return escaped.indexOf(" ") >= 0 ? "<" + escaped + ">" : escaped;
}
function escapeLinkTitle(title) {
  return title.replace(/"/g, '\\"');
}
function Rules(options) {
  this.options = options;
  this._keep = [];
  this._remove = [];
  this.blankRule = {
    replacement: options.blankReplacement
  };
  this.keepReplacement = options.keepReplacement;
  this.defaultRule = {
    replacement: options.defaultReplacement
  };
  this.array = [];
  for (var key in options.rules) this.array.push(options.rules[key]);
}
Rules.prototype = {
  add: function(key, rule) {
    this.array.unshift(rule);
  },
  keep: function(filter) {
    this._keep.unshift({
      filter,
      replacement: this.keepReplacement
    });
  },
  remove: function(filter) {
    this._remove.unshift({
      filter,
      replacement: function() {
        return "";
      }
    });
  },
  forNode: function(node) {
    if (node.isBlank) return this.blankRule;
    var rule;
    if (rule = findRule(this.array, node, this.options)) return rule;
    if (rule = findRule(this._keep, node, this.options)) return rule;
    if (rule = findRule(this._remove, node, this.options)) return rule;
    return this.defaultRule;
  },
  forEach: function(fn) {
    for (var i = 0; i < this.array.length; i++) fn(this.array[i], i);
  }
};
function findRule(rules2, node, options) {
  for (var i = 0; i < rules2.length; i++) {
    var rule = rules2[i];
    if (filterValue(rule, node, options)) return rule;
  }
  return void 0;
}
function filterValue(rule, node, options) {
  var filter = rule.filter;
  if (typeof filter === "string") {
    if (filter === node.nodeName.toLowerCase()) return true;
  } else if (Array.isArray(filter)) {
    if (filter.indexOf(node.nodeName.toLowerCase()) > -1) return true;
  } else if (typeof filter === "function") {
    if (filter.call(rule, node, options)) return true;
  } else {
    throw new TypeError("`filter` needs to be a string, array, or function");
  }
}
function collapseWhitespace(options) {
  var element = options.element;
  var isBlock2 = options.isBlock;
  var isVoid2 = options.isVoid;
  var isPre = options.isPre || function(node2) {
    return node2.nodeName === "PRE";
  };
  if (!element.firstChild || isPre(element)) return;
  var prevText = null;
  var keepLeadingWs = false;
  var prev = null;
  var node = next(prev, element, isPre);
  while (node !== element) {
    if (node.nodeType === 3 || node.nodeType === 4) {
      var text = node.data.replace(/[ \r\n\t]+/g, " ");
      if ((!prevText || / $/.test(prevText.data)) && !keepLeadingWs && text[0] === " ") {
        text = text.substr(1);
      }
      if (!text) {
        node = remove(node);
        continue;
      }
      node.data = text;
      prevText = node;
    } else if (node.nodeType === 1) {
      if (isBlock2(node) || node.nodeName === "BR") {
        if (prevText) {
          prevText.data = prevText.data.replace(/ $/, "");
        }
        prevText = null;
        keepLeadingWs = false;
      } else if (isVoid2(node) || isPre(node)) {
        prevText = null;
        keepLeadingWs = true;
      } else if (prevText) {
        keepLeadingWs = false;
      }
    } else {
      node = remove(node);
      continue;
    }
    var nextNode = next(prev, node, isPre);
    prev = node;
    node = nextNode;
  }
  if (prevText) {
    prevText.data = prevText.data.replace(/ $/, "");
    if (!prevText.data) {
      remove(prevText);
    }
  }
}
function remove(node) {
  var next2 = node.nextSibling || node.parentNode;
  node.parentNode.removeChild(node);
  return next2;
}
function next(prev, current, isPre) {
  if (prev && prev.parentNode === current || isPre(current)) {
    return current.nextSibling || current.parentNode;
  }
  return current.firstChild || current.nextSibling || current.parentNode;
}
var root = typeof window !== "undefined" ? window : {};
function canParseHTMLNatively() {
  var Parser = root.DOMParser;
  var canParse = false;
  try {
    if (new Parser().parseFromString("", "text/html")) {
      canParse = true;
    }
  } catch (e) {
  }
  return canParse;
}
function createHTMLParser() {
  var Parser = function() {
  };
  {
    if (shouldUseActiveX()) {
      Parser.prototype.parseFromString = function(string) {
        var doc = new window.ActiveXObject("htmlfile");
        doc.designMode = "on";
        doc.open();
        doc.write(string);
        doc.close();
        return doc;
      };
    } else {
      Parser.prototype.parseFromString = function(string) {
        var doc = document.implementation.createHTMLDocument("");
        doc.open();
        doc.write(string);
        doc.close();
        return doc;
      };
    }
  }
  return Parser;
}
function shouldUseActiveX() {
  var useActiveX = false;
  try {
    document.implementation.createHTMLDocument("").open();
  } catch (e) {
    if (root.ActiveXObject) useActiveX = true;
  }
  return useActiveX;
}
var HTMLParser = canParseHTMLNatively() ? root.DOMParser : createHTMLParser();
function RootNode(input, options) {
  var root2;
  if (typeof input === "string") {
    var doc = htmlParser().parseFromString(
      // DOM parsers arrange elements in the <head> and <body>.
      // Wrapping in a custom element ensures elements are reliably arranged in
      // a single element.
      '<x-turndown id="turndown-root">' + input + "</x-turndown>",
      "text/html"
    );
    root2 = doc.getElementById("turndown-root");
  } else {
    root2 = input.cloneNode(true);
  }
  collapseWhitespace({
    element: root2,
    isBlock,
    isVoid,
    isPre: options.preformattedCode ? isPreOrCode : null
  });
  return root2;
}
var _htmlParser;
function htmlParser() {
  _htmlParser = _htmlParser || new HTMLParser();
  return _htmlParser;
}
function isPreOrCode(node) {
  return node.nodeName === "PRE" || node.nodeName === "CODE";
}
function Node(node, options) {
  node.isBlock = isBlock(node);
  node.isCode = node.nodeName === "CODE" || node.parentNode.isCode;
  node.isBlank = isBlank(node);
  node.flankingWhitespace = flankingWhitespace(node, options);
  return node;
}
function isBlank(node) {
  return !isVoid(node) && !isMeaningfulWhenBlank(node) && /^\s*$/i.test(node.textContent) && !hasVoid(node) && !hasMeaningfulWhenBlank(node);
}
function flankingWhitespace(node, options) {
  if (node.isBlock || options.preformattedCode && node.isCode) {
    return {
      leading: "",
      trailing: ""
    };
  }
  var edges = edgeWhitespace(node.textContent);
  if (edges.leadingAscii && isFlankedByWhitespace("left", node, options)) {
    edges.leading = edges.leadingNonAscii;
  }
  if (edges.trailingAscii && isFlankedByWhitespace("right", node, options)) {
    edges.trailing = edges.trailingNonAscii;
  }
  return {
    leading: edges.leading,
    trailing: edges.trailing
  };
}
function edgeWhitespace(string) {
  var m = string.match(/^(([ \t\r\n]*)(\s*))(?:(?=\S)[\s\S]*\S)?((\s*?)([ \t\r\n]*))$/);
  return {
    leading: m[1],
    // whole string for whitespace-only strings
    leadingAscii: m[2],
    leadingNonAscii: m[3],
    trailing: m[4],
    // empty for whitespace-only strings
    trailingNonAscii: m[5],
    trailingAscii: m[6]
  };
}
function isFlankedByWhitespace(side, node, options) {
  var sibling;
  var regExp;
  var isFlanked;
  if (side === "left") {
    sibling = node.previousSibling;
    regExp = / $/;
  } else {
    sibling = node.nextSibling;
    regExp = /^ /;
  }
  if (sibling) {
    if (sibling.nodeType === 3) {
      isFlanked = regExp.test(sibling.nodeValue);
    } else if (options.preformattedCode && sibling.nodeName === "CODE") {
      isFlanked = false;
    } else if (sibling.nodeType === 1 && !isBlock(sibling)) {
      isFlanked = regExp.test(sibling.textContent);
    }
  }
  return isFlanked;
}
var reduce = Array.prototype.reduce;
function TurndownService(options) {
  if (!(this instanceof TurndownService)) return new TurndownService(options);
  var defaults = {
    rules: rules$1,
    headingStyle: "setext",
    hr: "* * *",
    bulletListMarker: "*",
    codeBlockStyle: "indented",
    fence: "```",
    emDelimiter: "_",
    strongDelimiter: "**",
    linkStyle: "inlined",
    linkReferenceStyle: "full",
    br: "  ",
    preformattedCode: false,
    blankReplacement: function(content, node) {
      return node.isBlock ? "\n\n" : "";
    },
    keepReplacement: function(content, node) {
      return node.isBlock ? "\n\n" + node.outerHTML + "\n\n" : node.outerHTML;
    },
    defaultReplacement: function(content, node) {
      return node.isBlock ? "\n\n" + content + "\n\n" : content;
    }
  };
  this.options = extend({}, defaults, options);
  this.rules = new Rules(this.options);
}
TurndownService.prototype = {
  /**
   * The entry point for converting a string or DOM node to Markdown
   * @public
   * @param {String|HTMLElement} input The string or DOM node to convert
   * @returns A Markdown representation of the input
   * @type String
   */
  turndown: function(input) {
    if (!canConvert(input)) {
      throw new TypeError(input + " is not a string, or an element/document/fragment node.");
    }
    if (input === "") return "";
    var output = process.call(this, new RootNode(input, this.options));
    return postProcess.call(this, output);
  },
  /**
   * Add one or more plugins
   * @public
   * @param {Function|Array} plugin The plugin or array of plugins to add
   * @returns The Turndown instance for chaining
   * @type Object
   */
  use: function(plugin) {
    if (Array.isArray(plugin)) {
      for (var i = 0; i < plugin.length; i++) this.use(plugin[i]);
    } else if (typeof plugin === "function") {
      plugin(this);
    } else {
      throw new TypeError("plugin must be a Function or an Array of Functions");
    }
    return this;
  },
  /**
   * Adds a rule
   * @public
   * @param {String} key The unique key of the rule
   * @param {Object} rule The rule
   * @returns The Turndown instance for chaining
   * @type Object
   */
  addRule: function(key, rule) {
    this.rules.add(key, rule);
    return this;
  },
  /**
   * Keep a node (as HTML) that matches the filter
   * @public
   * @param {String|Array|Function} filter The unique key of the rule
   * @returns The Turndown instance for chaining
   * @type Object
   */
  keep: function(filter) {
    this.rules.keep(filter);
    return this;
  },
  /**
   * Remove a node that matches the filter
   * @public
   * @param {String|Array|Function} filter The unique key of the rule
   * @returns The Turndown instance for chaining
   * @type Object
   */
  remove: function(filter) {
    this.rules.remove(filter);
    return this;
  },
  /**
   * Escapes Markdown syntax
   * @public
   * @param {String} string The string to escape
   * @returns A string with Markdown syntax escaped
   * @type String
   */
  escape: function(string) {
    return escapeMarkdown(string);
  }
};
function process(parentNode) {
  var self = this;
  return reduce.call(parentNode.childNodes, function(output, node) {
    node = new Node(node, self.options);
    var replacement = "";
    if (node.nodeType === 3) {
      replacement = node.isCode ? node.nodeValue : self.escape(node.nodeValue);
    } else if (node.nodeType === 1) {
      replacement = replacementForNode.call(self, node);
    }
    return join(output, replacement);
  }, "");
}
function postProcess(output) {
  var self = this;
  this.rules.forEach(function(rule) {
    if (typeof rule.append === "function") {
      output = join(output, rule.append(self.options));
    }
  });
  return output.replace(/^[\t\r\n]+/, "").replace(/[\t\r\n\s]+$/, "");
}
function replacementForNode(node) {
  var rule = this.rules.forNode(node);
  var content = process.call(this, node);
  var whitespace = node.flankingWhitespace;
  if (whitespace.leading || whitespace.trailing) content = content.trim();
  return whitespace.leading + rule.replacement(content, node, this.options) + whitespace.trailing;
}
function join(output, replacement) {
  var s1 = trimTrailingNewlines(output);
  var s2 = trimLeadingNewlines(replacement);
  var nls = Math.max(output.length - s1.length, replacement.length - s2.length);
  var separator = "\n\n".substring(0, nls);
  return s1 + separator + s2;
}
function canConvert(input) {
  return input != null && (typeof input === "string" || input.nodeType && (input.nodeType === 1 || input.nodeType === 9 || input.nodeType === 11));
}
var highlightRegExp = /highlight-(?:text|source)-([a-z0-9]+)/;
function highlightedCodeBlock(turndownService) {
  turndownService.addRule("highlightedCodeBlock", {
    filter: function(node) {
      var firstChild = node.firstChild;
      return node.nodeName === "DIV" && highlightRegExp.test(node.className) && firstChild && firstChild.nodeName === "PRE";
    },
    replacement: function(content, node, options) {
      var className = node.className || "";
      var language = (className.match(highlightRegExp) || [null, ""])[1];
      return "\n\n" + options.fence + language + "\n" + node.firstChild.textContent + "\n" + options.fence + "\n\n";
    }
  });
}
function strikethrough(turndownService) {
  turndownService.addRule("strikethrough", {
    filter: ["del", "s", "strike"],
    replacement: function(content) {
      return "~" + content + "~";
    }
  });
}
var indexOf = Array.prototype.indexOf;
var every = Array.prototype.every;
var rules = {};
rules.tableCell = {
  filter: ["th", "td"],
  replacement: function(content, node) {
    return cell(content, node);
  }
};
rules.tableRow = {
  filter: "tr",
  replacement: function(content, node) {
    var borderCells = "";
    var alignMap = { left: ":--", right: "--:", center: ":-:" };
    if (isHeadingRow(node)) {
      for (var i = 0; i < node.childNodes.length; i++) {
        var border = "---";
        var align = (node.childNodes[i].getAttribute("align") || "").toLowerCase();
        if (align) border = alignMap[align] || border;
        borderCells += cell(border, node.childNodes[i]);
      }
    }
    return "\n" + content + (borderCells ? "\n" + borderCells : "");
  }
};
rules.table = {
  // Only convert tables with a heading row.
  // Tables with no heading row are kept using `keep` (see below).
  filter: function(node) {
    return node.nodeName === "TABLE" && isHeadingRow(node.rows[0]);
  },
  replacement: function(content) {
    content = content.replace("\n\n", "\n");
    return "\n\n" + content + "\n\n";
  }
};
rules.tableSection = {
  filter: ["thead", "tbody", "tfoot"],
  replacement: function(content) {
    return content;
  }
};
function isHeadingRow(tr) {
  var parentNode = tr.parentNode;
  return parentNode.nodeName === "THEAD" || parentNode.firstChild === tr && (parentNode.nodeName === "TABLE" || isFirstTbody(parentNode)) && every.call(tr.childNodes, function(n) {
    return n.nodeName === "TH";
  });
}
function isFirstTbody(element) {
  var previousSibling = element.previousSibling;
  return element.nodeName === "TBODY" && (!previousSibling || previousSibling.nodeName === "THEAD" && /^\s*$/i.test(previousSibling.textContent));
}
function cell(content, node) {
  var index = indexOf.call(node.parentNode.childNodes, node);
  var prefix = " ";
  if (index === 0) prefix = "| ";
  return prefix + content + " |";
}
function tables(turndownService) {
  turndownService.keep(function(node) {
    return node.nodeName === "TABLE" && !isHeadingRow(node.rows[0]);
  });
  for (var key in rules) turndownService.addRule(key, rules[key]);
}
function taskListItems(turndownService) {
  turndownService.addRule("taskListItems", {
    filter: function(node) {
      return node.type === "checkbox" && node.parentNode.nodeName === "LI";
    },
    replacement: function(content, node) {
      return (node.checked ? "[x]" : "[ ]") + " ";
    }
  });
}
function gfm(turndownService) {
  turndownService.use([
    highlightedCodeBlock,
    strikethrough,
    tables,
    taskListItems
  ]);
}
let td = null;
function getTurndown() {
  if (td) return td;
  td = new TurndownService({
    headingStyle: "atx",
    codeBlockStyle: "fenced",
    bulletListMarker: "-",
    emDelimiter: "*",
    hr: "---",
    linkStyle: "inlined"
  });
  td.use(gfm);
  td.use([strikethrough, tables, taskListItems]);
  td.addRule("imgBase64Keep", {
    filter: (node) => node.nodeName === "IMG",
    replacement: (_content, node) => {
      const el = node;
      const src = el.getAttribute("src") || "";
      if (!src) return "";
      if (src.startsWith("data:")) {
        const alt2 = escapeAttr(el.getAttribute("alt") || "");
        return `<img src="${src}" alt="${alt2}" />`;
      }
      const alt = el.getAttribute("alt") || "";
      const title = el.getAttribute("title");
      return title ? `![${alt}](${src} "${title}")` : `![${alt}](${src})`;
    }
  });
  return td;
}
function htmlToMarkdown(html) {
  return getTurndown().turndown(html);
}
async function inlineImages(html, opts = {}) {
  const concurrency = opts.concurrency ?? 4;
  const maxSize = opts.maxSizeBytes ?? 5 * 1024 * 1024;
  const timeoutMs = opts.timeoutMs ?? 8e3;
  const imgRegex = /<img\b[^>]*?\bsrc\s*=\s*(?:"([^"]*)"|'([^']*)')([^>]*)>/gi;
  const imgEntries = [];
  let match;
  while ((match = imgRegex.exec(html)) !== null) {
    const src = match[1] ?? match[2] ?? "";
    imgEntries.push({ fullMatch: match[0], src });
  }
  const queue = [];
  const seen = /* @__PURE__ */ new Set();
  for (const entry of imgEntries) {
    if (/^https?:\/\//i.test(entry.src) && !seen.has(entry.src)) {
      seen.add(entry.src);
      queue.push(entry.src);
    }
  }
  const fetchOne = async (src) => {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
      const res = await fetch(src, {
        credentials: "omit",
        signal: ctrl.signal
        // 明确不发 cookie，避免把用户会话带进备份里
      });
      if (!res.ok) return null;
      const buf = await res.arrayBuffer();
      if (buf.byteLength > maxSize) return null;
      const mime = res.headers.get("content-type")?.split(";")[0].trim() || guessMime(src);
      if (!mime.startsWith("image/")) return null;
      return `data:${mime};base64,${arrayBufferToBase64(buf)}`;
    } catch {
      return null;
    } finally {
      clearTimeout(timer);
    }
  };
  const results = /* @__PURE__ */ new Map();
  let idx = 0;
  const workers = [];
  for (let i = 0; i < concurrency; i++) {
    workers.push(
      (async () => {
        while (idx < queue.length) {
          const my = idx++;
          const src = queue[my];
          const data = await fetchOne(src);
          results.set(src, data);
        }
      })()
    );
  }
  await Promise.all(workers);
  let ok = 0;
  let failed = 0;
  let skipped = 0;
  let resultHtml = html;
  for (const entry of imgEntries) {
    if (!/^https?:\/\//i.test(entry.src)) {
      skipped++;
      continue;
    }
    const data = results.get(entry.src);
    if (data) {
      const newTag = entry.fullMatch.replace(entry.src, data);
      resultHtml = resultHtml.replace(entry.fullMatch, newTag);
      ok++;
    } else {
      failed++;
    }
  }
  return { html: resultHtml, ok, failed, skipped };
}
function arrayBufferToBase64(buf) {
  const bytes = new Uint8Array(buf);
  const CHUNK = 32768;
  let binary = "";
  for (let i = 0; i < bytes.length; i += CHUNK) {
    binary += String.fromCharCode.apply(
      null,
      Array.from(bytes.subarray(i, i + CHUNK))
    );
  }
  return btoa(binary);
}
function guessMime(url) {
  const m = url.toLowerCase().match(/\.(png|jpe?g|gif|webp|bmp|svg)(\?|$)/);
  if (!m) return "image/png";
  const ext = m[1];
  if (ext === "jpg" || ext === "jpeg") return "image/jpeg";
  if (ext === "svg") return "image/svg+xml";
  return `image/${ext}`;
}
function buildContentBundle(params) {
  const { title, html, sourceUrl, siteName, format, includeSource, tags, comment } = params;
  const commentHtml = comment?.trim() ? `<blockquote><p>💬 ${escapeText(comment.trim())}</p></blockquote>
` : "";
  const footerParts = [];
  if (includeSource) {
    footerParts.push(
      `<hr/>
<p><small>📎 来源：<a href="${escapeAttr(sourceUrl)}">${escapeText(siteName || sourceUrl)}</a></small></p>`
    );
  }
  if (tags.length > 0) {
    footerParts.push(
      `<p><small>🏷️ ${tags.map((t) => `#${escapeText(t)}`).join(" ")}</small></p>`
    );
  }
  const footer = footerParts.join("\n");
  const fullHtml = `<h1>${escapeText(title)}</h1>
${commentHtml}${html}
${footer}`;
  if (format === "html") {
    const text2 = fullHtml.replace(/<[^>]+>/g, "").replace(/\s+/g, " ").trim();
    return { content: fullHtml, contentText: text2 };
  }
  const md = htmlToMarkdown(fullHtml);
  const text = md.replace(/[#*>`_~\[\]\(\)!-]/g, "").replace(/\s+/g, " ").trim();
  return { content: md, contentText: text };
}
function escapeText(s) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function escapeAttr(s) {
  return escapeText(s).replace(/"/g, "&quot;");
}
chrome.runtime.onInstalled.addListener(() => {
  try {
    chrome.contextMenus.removeAll(() => {
      chrome.contextMenus.create({
        id: "nowen-clip-selection",
        title: "剪藏选中内容到 Nowen Note",
        contexts: ["selection"]
      });
      chrome.contextMenus.create({
        id: "nowen-clip-page",
        title: "剪藏整个页面到 Nowen Note",
        contexts: ["page"]
      });
      chrome.contextMenus.create({
        id: "nowen-clip-simplified",
        title: "剪藏简化内容到 Nowen Note",
        contexts: ["page"]
      });
      chrome.contextMenus.create({
        id: "nowen-clip-fullpage",
        title: "完全克隆页面到 Nowen Note",
        contexts: ["page"]
      });
      chrome.contextMenus.create({
        id: "nowen-clip-screenshot",
        title: "截图当前可视区域到 Nowen Note",
        contexts: ["page"]
      });
      chrome.contextMenus.create({
        id: "nowen-clip-full-screenshot",
        title: "截图整个页面到 Nowen Note",
        contexts: ["page"]
      });
      chrome.contextMenus.create({
        id: "nowen-clip-link",
        title: "剪藏这个链接到 Nowen Note",
        contexts: ["link"]
      });
    });
  } catch (e) {
    console.warn("[nowen-clipper] create contextMenus failed:", e);
  }
});
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (!tab?.id) return;
  if (info.menuItemId === "nowen-clip-selection") {
    void runClip({ type: "CLIP_REQUEST", mode: "selection", tabId: tab.id });
  } else if (info.menuItemId === "nowen-clip-page") {
    void runClip({ type: "CLIP_REQUEST", mode: "article", tabId: tab.id });
  } else if (info.menuItemId === "nowen-clip-simplified") {
    void runClip({ type: "CLIP_REQUEST", mode: "simplified", tabId: tab.id });
  } else if (info.menuItemId === "nowen-clip-fullpage") {
    void runClip({ type: "CLIP_REQUEST", mode: "fullpage", tabId: tab.id });
  } else if (info.menuItemId === "nowen-clip-screenshot") {
    void runClip({ type: "CLIP_REQUEST", mode: "screenshot", tabId: tab.id });
  } else if (info.menuItemId === "nowen-clip-full-screenshot") {
    void runClip({ type: "CLIP_REQUEST", mode: "fullScreenshot", tabId: tab.id });
  } else if (info.menuItemId === "nowen-clip-link" && info.linkUrl) {
    void clipLinkOnly(info.linkUrl, tab);
  }
});
chrome.commands?.onCommand.addListener(async (command) => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return;
  if (command === "clip-page") {
    void runClip({ type: "CLIP_REQUEST", mode: "article", tabId: tab.id });
  } else if (command === "clip-selection") {
    void runClip({ type: "CLIP_REQUEST", mode: "selection", tabId: tab.id });
  }
});
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || msg.type !== "CLIP_REQUEST") return void 0;
  console.log("[nowen-clipper] 收到 CLIP_REQUEST, mode =", msg.mode, "完整消息:", JSON.stringify(msg));
  (async () => {
    try {
      const result = await runClip(msg);
      sendResponse(result);
    } catch (e) {
      sendResponse({ ok: false, error: String(e?.message || e) });
    }
  })();
  return true;
});
async function runClip(req) {
  console.log("[nowen-clipper] runClip 开始, mode =", req.mode);
  const cfg = await getConfig();
  if (!isConfigured(cfg)) {
    notify(
      "请先设置 Nowen Note",
      "右键扩展图标 → 选项，填入服务器地址并登录账号。"
    );
    try {
      await chrome.runtime.openOptionsPage();
    } catch {
    }
    return { ok: false, error: "未配置服务器地址或未登录" };
  }
  if (req.mode === "screenshot" || req.mode === "fullScreenshot") {
    console.log("[nowen-clipper] 进入截图流程, mode =", req.mode);
    return runScreenshotClip(req);
  }
  sendProgress({ type: "CLIP_PROGRESS", phase: "extract", message: "正在抽取页面内容..." });
  const extractMode = req.mode === "simplified" ? "simplified" : req.mode === "selection" ? "selection" : req.mode === "fullpage" ? "fullpage" : "article";
  console.log("[nowen-clipper] extractMode =", extractMode);
  const extracted = await requestExtract(req.tabId, extractMode);
  if (!extracted.ok || !extracted.data) {
    notify("剪藏失败", extracted.error || "内容抽取失败");
    return { ok: false, error: extracted.error };
  }
  const data = extracted.data;
  let html = data.html;
  if (req.mode === "fullpage") {
    sendProgress({ type: "CLIP_PROGRESS", phase: "upload", message: "正在上传完整页面到 Nowen Note..." });
    const notebookName2 = (req.overrideNotebook ?? cfg.defaultNotebook).trim() || "Web 剪藏";
    const tags2 = parseTags(req.overrideTags ?? cfg.defaultTags);
    const metaParts = [];
    if (req.comment?.trim()) metaParts.push(`<!-- clipper-comment: ${req.comment.trim()} -->`);
    if (tags2.length) metaParts.push(`<!-- clipper-tags: ${tags2.join(",")} -->`);
    if (cfg.includeSource) metaParts.push(`<!-- clipper-source: ${data.url} -->`);
    let content2 = html;
    if (metaParts.length > 0) {
      const metaBlock = "\n" + metaParts.join("\n") + "\n";
      if (content2.includes("<head>")) {
        content2 = content2.replace("<head>", "<head>" + metaBlock);
      } else if (content2.includes("<HEAD>")) {
        content2 = content2.replace("<HEAD>", "<HEAD>" + metaBlock);
      } else {
        const dtMatch = content2.match(/<!DOCTYPE[^>]*>/i);
        if (dtMatch) {
          const idx = (dtMatch.index ?? 0) + dtMatch[0].length;
          content2 = content2.slice(0, idx) + metaBlock + content2.slice(idx);
        } else {
          content2 = content2 + metaBlock;
        }
      }
    }
    const contentText2 = data.text.slice(0, 5e3);
    try {
      const resp = await importNote(cfg, {
        title: data.title,
        content: content2,
        contentText: contentText2,
        notebookName: notebookName2
      });
      const noteId = resp.notes?.[0]?.id;
      sendProgress({
        type: "CLIP_PROGRESS",
        phase: "done",
        message: `已保存到「${notebookName2}」`,
        noteId
      });
      notify("剪藏成功", `完整页面已保存到「${notebookName2}」`);
      return { ok: true, noteId, noteTitle: data.title };
    } catch (e) {
      const msg = describeError(e);
      sendProgress({ type: "CLIP_PROGRESS", phase: "error", message: msg });
      notify("剪藏失败", msg);
      return { ok: false, error: msg };
    }
  }
  let images = { ok: 0, failed: 0, skipped: 0 };
  if (req.mode !== "simplified" && cfg.imageMode === "inline") {
    sendProgress({
      type: "CLIP_PROGRESS",
      phase: "download-images",
      message: "正在下载并内联图片..."
    });
    const result = await inlineImages(html);
    html = result.html;
    images = { ok: result.ok, failed: result.failed, skipped: result.skipped };
  } else if (cfg.imageMode === "skip") {
    html = html.replace(/<img\b[^>]*>/gi, "");
  }
  sendProgress({
    type: "CLIP_PROGRESS",
    phase: "transform",
    message: "正在转换格式..."
  });
  const tags = parseTags(req.overrideTags ?? cfg.defaultTags);
  const { content, contentText } = buildContentBundle({
    title: data.title,
    html,
    sourceUrl: data.url,
    siteName: data.siteName,
    format: cfg.outputFormat,
    includeSource: cfg.includeSource,
    tags,
    comment: req.comment
  });
  sendProgress({ type: "CLIP_PROGRESS", phase: "upload", message: "正在上传到 Nowen Note..." });
  const notebookName = (req.overrideNotebook ?? cfg.defaultNotebook).trim() || "Web 剪藏";
  try {
    const resp = await importNote(cfg, {
      title: data.title,
      content,
      contentText,
      notebookName
    });
    const noteId = resp.notes?.[0]?.id;
    sendProgress({
      type: "CLIP_PROGRESS",
      phase: "done",
      message: `已保存到「${notebookName}」`,
      noteId,
      images
    });
    notify(
      "剪藏成功",
      `已保存到「${notebookName}」${images.failed ? `（${images.failed} 张图片下载失败）` : ""}`
    );
    return { ok: true, noteId, noteTitle: data.title, images };
  } catch (e) {
    const msg = describeError(e);
    sendProgress({ type: "CLIP_PROGRESS", phase: "error", message: msg });
    notify("剪藏失败", msg);
    return { ok: false, error: msg };
  }
}
async function runScreenshotClip(req) {
  const cfg = await getConfig();
  await sleep(800);
  if (req.mode === "screenshot") {
    sendProgress({ type: "CLIP_PROGRESS", phase: "screenshot", message: "正在截取当前屏幕..." });
    const dataUrl = await captureWithRetry();
    if (!dataUrl) {
      const msg = "截图失败：无法截取当前屏幕";
      sendProgress({ type: "CLIP_PROGRESS", phase: "error", message: msg });
      notify("截图失败", msg);
      return { ok: false, error: msg };
    }
    return await uploadScreenshot(cfg, req, dataUrl, "屏幕截图");
  }
  sendProgress({ type: "CLIP_PROGRESS", phase: "screenshot", message: "正在截取整个页面..." });
  try {
    const fullPageDataUrl = await captureFullPageViaDebugger(req.tabId);
    return await uploadScreenshot(cfg, req, fullPageDataUrl, "整页截图");
  } catch (e) {
    const msg = `全页截图失败：${String(e?.message || e)}`;
    sendProgress({ type: "CLIP_PROGRESS", phase: "error", message: msg });
    notify("截图失败", msg);
    return { ok: false, error: msg };
  }
}
async function captureFullPageViaDebugger(tabId) {
  const target = { tabId };
  await chrome.debugger.attach(target, "1.3");
  try {
    const injectResult = await chrome.debugger.sendCommand(
      target,
      "Runtime.evaluate",
      {
        expression: `
          (function() {
            // 先收集所有 fixed/sticky 元素
            var fixedEls = [];
            var allEls = document.querySelectorAll('*');
            for (var i = 0; i < allEls.length; i++) {
              var cs = window.getComputedStyle(allEls[i]);
              if (cs.position === 'fixed' || cs.position === 'sticky') {
                fixedEls.push(allEls[i]);
              }
            }
            // 创建一个 style 标签，只针对 fixed/sticky 元素添加覆盖
            var style = document.createElement('style');
            style.id = '__nowen_clipper_disable_fixed__';
            style.textContent = '[data-nowen-was-fixed] { position: absolute !important; }';
            document.head.appendChild(style);
            // 给 fixed/sticky 元素打标记
            for (var j = 0; j < fixedEls.length; j++) {
              fixedEls[j].setAttribute('data-nowen-was-fixed', fixedEls[j].style.position || '');
            }
            return fixedEls.length;
          })()
        `,
        returnByValue: true
      }
    );
    console.log(
      "[nowen-clipper] 通过 CDP 禁用了",
      injectResult?.result?.value ?? 0,
      "个 fixed/sticky 元素"
    );
    await sleep(200);
    const layoutMetrics = await chrome.debugger.sendCommand(
      target,
      "Page.getLayoutMetrics"
    );
    const { width, height } = layoutMetrics.cssContentSize || layoutMetrics.contentSize;
    const maxHeight = 16384;
    const captureHeight = Math.min(height, maxHeight);
    await chrome.debugger.sendCommand(target, "Emulation.setDeviceMetricsOverride", {
      width: Math.ceil(width),
      height: Math.ceil(captureHeight),
      deviceScaleFactor: 1,
      mobile: false
    });
    await sleep(500);
    const screenshot = await chrome.debugger.sendCommand(
      target,
      "Page.captureScreenshot",
      {
        format: "png",
        captureBeyondViewport: true,
        clip: {
          x: 0,
          y: 0,
          width,
          height: captureHeight,
          scale: 1
        }
      }
    );
    await chrome.debugger.sendCommand(target, "Runtime.evaluate", {
      expression: `
        (function() {
          var style = document.getElementById('__nowen_clipper_disable_fixed__');
          if (style) style.remove();
          var marked = document.querySelectorAll('[data-nowen-was-fixed]');
          for (var i = 0; i < marked.length; i++) {
            marked[i].removeAttribute('data-nowen-was-fixed');
          }
        })()
      `
    });
    await chrome.debugger.sendCommand(target, "Emulation.clearDeviceMetricsOverride", {});
    return `data:image/png;base64,${screenshot.data}`;
  } finally {
    try {
      await chrome.debugger.detach(target);
    } catch {
    }
  }
}
async function uploadScreenshot(cfg, req, dataUrl, titleSuffix) {
  sendProgress({ type: "CLIP_PROGRESS", phase: "upload", message: "正在上传截图..." });
  let pageTitle = titleSuffix;
  try {
    const tab = await chrome.tabs.get(req.tabId);
    pageTitle = `${tab.title || "页面"} - ${titleSuffix}`;
  } catch {
  }
  const notebookName = (req.overrideNotebook ?? cfg.defaultNotebook).trim() || "Web 剪藏";
  const tags = parseTags(req.overrideTags ?? cfg.defaultTags);
  let pageUrl = "";
  try {
    const tab = await chrome.tabs.get(req.tabId);
    pageUrl = tab.url || "";
  } catch {
  }
  const imgHtml = `<img src="${dataUrl}" alt="${escapeHtml(titleSuffix)}" />`;
  const { content, contentText } = buildContentBundle({
    title: pageTitle,
    html: imgHtml,
    sourceUrl: pageUrl,
    siteName: "",
    format: cfg.outputFormat,
    includeSource: cfg.includeSource,
    tags,
    comment: req.comment
  });
  try {
    const resp = await importNote(cfg, {
      title: pageTitle,
      content,
      contentText,
      notebookName
    });
    const noteId = resp.notes?.[0]?.id;
    sendProgress({
      type: "CLIP_PROGRESS",
      phase: "done",
      message: `截图已保存到「${notebookName}」`,
      noteId
    });
    notify("截图剪藏成功", `已保存到「${notebookName}」`);
    return { ok: true, noteId, noteTitle: pageTitle };
  } catch (e) {
    const msg = describeError(e);
    sendProgress({ type: "CLIP_PROGRESS", phase: "error", message: msg });
    notify("截图剪藏失败", msg);
    return { ok: false, error: msg };
  }
}
async function requestExtract(tabId, mode) {
  const msg = { type: "EXTRACT_REQUEST", mode };
  console.log("[nowen-clipper] requestExtract: tabId =", tabId, "mode =", mode);
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["content.js"]
    });
  } catch (e) {
    console.warn("[nowen-clipper] 注入 content.js 失败:", e?.message || e);
  }
  try {
    const res = await chrome.tabs.sendMessage(tabId, msg);
    if (res && res.type === "EXTRACT_RESPONSE") {
      console.log("[nowen-clipper] requestExtract 成功, ok =", res.ok, "mode =", res.data?.mode);
      return res;
    }
    return {
      type: "EXTRACT_RESPONSE",
      ok: false,
      error: "Content script 返回了非预期的响应格式"
    };
  } catch (e) {
    return {
      type: "EXTRACT_RESPONSE",
      ok: false,
      error: `无法在该页面运行剪藏（${String(e?.message || e)}）。某些浏览器特殊页面（如设置页、扩展商店）不支持剪藏。`
    };
  }
}
async function clipLinkOnly(url, tab) {
  const cfg = await getConfig();
  if (!isConfigured(cfg)) {
    void chrome.runtime.openOptionsPage();
    return;
  }
  const title = tab.title || url;
  const html = `<h1>${escapeHtml(title)}</h1><p><a href="${escapeHtml(url)}">${escapeHtml(url)}</a></p>`;
  const bundle = buildContentBundle({
    title,
    html,
    sourceUrl: url,
    siteName: new URL(url).hostname,
    format: cfg.outputFormat,
    includeSource: cfg.includeSource,
    tags: parseTags(cfg.defaultTags)
  });
  try {
    await importNote(cfg, {
      title,
      content: bundle.content,
      contentText: bundle.contentText,
      notebookName: cfg.defaultNotebook || "Web 剪藏"
    });
    notify("链接已保存", title);
  } catch (e) {
    notify("剪藏失败", describeError(e));
  }
}
function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
async function captureWithRetry(maxRetries = 4) {
  let delay = 500;
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      return await chrome.tabs.captureVisibleTab(void 0, { format: "png" });
    } catch (e) {
      const msg = String(e?.message || e);
      if (msg.includes("MAX_CAPTURE") && attempt < maxRetries) {
        console.warn(`[nowen-clipper] captureVisibleTab quota hit, retrying in ${delay}ms (attempt ${attempt + 1}/${maxRetries})`);
        await sleep(delay);
        delay *= 2;
        continue;
      }
      console.error("[nowen-clipper] captureVisibleTab failed:", msg);
      return null;
    }
  }
  return null;
}
function sendProgress(p) {
  try {
    chrome.runtime.sendMessage(p).catch(() => {
    });
  } catch {
  }
}
function notify(title, message) {
  try {
    chrome.notifications?.create({
      type: "basic",
      iconUrl: chrome.runtime.getURL("icons/icon-128.png"),
      title,
      message: message.slice(0, 300),
      priority: 1
    });
  } catch {
  }
}
function parseTags(raw) {
  return raw.split(/[,，]/).map((s) => s.trim()).filter((s) => s.length > 0);
}
function describeError(e) {
  if (e instanceof NowenApiError) {
    if (e.status === 401) return "登录已过期或失效，请在扩展选项中重新登录。";
    if (e.status === 403) return "权限不足：" + e.message;
    return e.message;
  }
  if (e instanceof Error) return e.message;
  return String(e);
}
function escapeHtml(s) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
