import "./chunks/modulepreload-polyfill-DaKOjhqt.js";
import { g as getConfig, n as normalizeBaseUrl, s as setConfig } from "./chunks/storage-DiurM1t3.js";
import { p as ping, l as login, v as verify2FA } from "./chunks/api-BSyEg_1v.js";
let pending2FATicket = "";
let pending2FAServerUrl = "";
async function init() {
  const cfg = await getConfig();
  document.getElementById("serverUrl").value = cfg.serverUrl;
  document.getElementById("username").value = cfg.username;
  document.getElementById("defaultNotebook").value = cfg.defaultNotebook;
  document.getElementById("defaultTags").value = cfg.defaultTags;
  document.getElementById("imageMode").value = cfg.imageMode;
  document.getElementById("outputFormat").value = cfg.outputFormat;
  document.getElementById("includeSource").checked = cfg.includeSource;
  document.getElementById("toggle-password").addEventListener("click", () => {
    const el = document.getElementById("password");
    el.type = el.type === "password" ? "text" : "password";
  });
  document.getElementById("login-btn").addEventListener("click", onLogin);
  document.getElementById("twofa-btn").addEventListener("click", on2FAVerify);
  document.getElementById("logout-btn").addEventListener("click", onLogout);
  document.getElementById("relogin-btn").addEventListener("click", onRelogin);
  document.getElementById("save").addEventListener("click", onSave);
  if (cfg.token) {
    try {
      const r = await ping(cfg);
      showLoggedIn(r.username, r.role);
    } catch {
      showLoginForm();
    }
  } else {
    showLoginForm();
  }
}
function showLoginForm() {
  document.getElementById("login-card").classList.remove("hidden");
  document.getElementById("status-card").classList.add("hidden");
}
function showLoggedIn(username, role) {
  document.getElementById("login-card").classList.add("hidden");
  document.getElementById("status-card").classList.remove("hidden");
  document.getElementById("status-user").textContent = `${username}（${role}）`;
}
async function onLogin() {
  const el = document.getElementById("login-result");
  el.className = "test-result";
  el.textContent = "登录中...";
  const serverUrl = normalizeBaseUrl(
    document.getElementById("serverUrl").value
  );
  const username = document.getElementById("username").value.trim();
  const password = document.getElementById("password").value;
  if (!serverUrl) {
    el.classList.add("err");
    el.textContent = "请先填写服务器地址";
    return;
  }
  if (!username || !password) {
    el.classList.add("err");
    el.textContent = "请填写用户名和密码";
    return;
  }
  try {
    const r = await login(serverUrl, username, password);
    if (r.requires2FA && r.ticket) {
      pending2FATicket = r.ticket;
      pending2FAServerUrl = serverUrl;
      el.classList.add("ok");
      el.textContent = `密码验证通过，请输入两步验证码（${r.username}）`;
      document.getElementById("twofa-section").classList.remove("hidden");
      document.getElementById("twofa-code").focus();
      return;
    }
    await handleLoginSuccess(serverUrl, username, r);
    el.classList.add("ok");
    el.textContent = `✅ 登录成功`;
  } catch (e) {
    el.classList.add("err");
    el.textContent = `❌ ${String(e?.message || e)}`;
  }
}
async function on2FAVerify() {
  const el = document.getElementById("twofa-result");
  el.className = "test-result";
  el.textContent = "验证中...";
  const code = document.getElementById("twofa-code").value.trim();
  if (!code) {
    el.classList.add("err");
    el.textContent = "请输入验证码";
    return;
  }
  try {
    const r = await verify2FA(pending2FAServerUrl, pending2FATicket, code);
    const username = document.getElementById("username").value.trim();
    await handleLoginSuccess(pending2FAServerUrl, username, r);
    el.classList.add("ok");
    el.textContent = "✅ 验证成功";
    document.getElementById("twofa-section").classList.add("hidden");
  } catch (e) {
    el.classList.add("err");
    el.textContent = `❌ ${String(e?.message || e)}`;
  }
}
async function handleLoginSuccess(serverUrl, username, r) {
  await setConfig({
    serverUrl,
    username,
    token: r.token,
    displayName: r.user.displayName || username
  });
  showLoggedIn(username, r.user.role);
  document.getElementById("password").value = "";
}
async function onLogout() {
  await setConfig({ token: "", displayName: "" });
  showLoginForm();
  const el = document.getElementById("login-result");
  el.className = "test-result ok";
  el.textContent = "已退出登录";
  setTimeout(() => el.textContent = "", 2e3);
}
function onRelogin() {
  showLoginForm();
  document.getElementById("login-result").textContent = "";
}
function readForm() {
  return {
    serverUrl: normalizeBaseUrl(
      document.getElementById("serverUrl").value
    ),
    defaultNotebook: document.getElementById("defaultNotebook").value.trim(),
    defaultTags: document.getElementById("defaultTags").value.trim(),
    imageMode: document.getElementById("imageMode").value,
    outputFormat: document.getElementById("outputFormat").value,
    includeSource: document.getElementById("includeSource").checked
  };
}
async function onSave() {
  const el = document.getElementById("save-result");
  el.className = "save-result";
  const patch = readForm();
  await setConfig(patch);
  el.classList.add("ok");
  el.textContent = "已保存";
  setTimeout(() => el.textContent = "", 2e3);
}
void init();
