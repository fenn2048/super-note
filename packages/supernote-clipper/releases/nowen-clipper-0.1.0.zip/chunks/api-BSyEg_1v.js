import { n as normalizeBaseUrl } from "./storage-DiurM1t3.js";
class NowenApiError extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
    this.name = "NowenApiError";
  }
}
function authHeaders(cfg) {
  return {
    Authorization: `Bearer ${cfg.token}`,
    "Content-Type": "application/json"
  };
}
async function parseErr(res) {
  let code;
  let message = res.statusText;
  try {
    const data = await res.json();
    code = data.code;
    if (data.error) message = data.error;
  } catch {
    try {
      message = await res.text() || message;
    } catch {
    }
  }
  return new NowenApiError(res.status, code, `[${res.status}] ${message}`);
}
async function login(serverUrl, username, password) {
  const base = normalizeBaseUrl(serverUrl);
  const res = await fetch(`${base}/api/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, password })
  });
  if (!res.ok) throw await parseErr(res);
  return await res.json();
}
async function verify2FA(serverUrl, ticket, code) {
  const base = normalizeBaseUrl(serverUrl);
  const res = await fetch(`${base}/api/auth/2fa/verify`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ticket, code })
  });
  if (!res.ok) throw await parseErr(res);
  return await res.json();
}
async function ping(cfg) {
  const base = normalizeBaseUrl(cfg.serverUrl);
  const res = await fetch(`${base}/api/me`, {
    method: "GET",
    headers: authHeaders(cfg)
  });
  if (!res.ok) throw await parseErr(res);
  return await res.json();
}
async function importNote(cfg, payload) {
  const base = normalizeBaseUrl(cfg.serverUrl);
  const body = {
    notes: [
      {
        title: payload.title,
        content: payload.content,
        contentText: payload.contentText,
        notebookName: payload.notebookName,
        notebookPath: payload.notebookPath,
        createdAt: payload.createdAt,
        updatedAt: payload.updatedAt
      }
    ]
  };
  if (payload.notebookName && !payload.notebookPath) {
    body.notebookName = payload.notebookName;
  }
  const res = await fetch(`${base}/api/export/import`, {
    method: "POST",
    headers: authHeaders(cfg),
    body: JSON.stringify(body)
  });
  if (!res.ok) throw await parseErr(res);
  return await res.json();
}
export {
  NowenApiError as N,
  importNote as i,
  login as l,
  ping as p,
  verify2FA as v
};
