import "./chunks/modulepreload-polyfill-DaKOjhqt.js";
import { g as getConfig, a as setConfig, p as ping, b as getClipWorkspaces, c as getClipNotebooks } from "./chunks/api-DhBVDGjp.js";
let checkTimeout = null;
async function init() {
  const cfg = await getConfig();
  const serverInput = document.getElementById("server-url");
  const tokenInput = document.getElementById("api-token");
  const imageLocCheckbox = document.getElementById("image-localization");
  const quickCaptureCheckbox = document.getElementById("quick-capture");
  serverInput.value = cfg.serverUrl || "";
  tokenInput.value = cfg.token || "";
  imageLocCheckbox.checked = cfg.imageLocalization;
  quickCaptureCheckbox.checked = cfg.quickCapture || false;
  const aiEnhanceCheckbox = document.getElementById("ai-enhance");
  const aiModeSelect = document.getElementById("ai-mode");
  aiEnhanceCheckbox.checked = cfg.aiEnhanceEnabled;
  aiModeSelect.value = cfg.aiEnhanceMode;
  document.querySelectorAll("#ai-details input[data-task]").forEach((el) => {
    const k = el.dataset.task;
    el.checked = !!cfg.aiEnhanceTasks[k];
  });
  const aiDetails = document.getElementById("ai-details");
  if (cfg.aiEnhanceEnabled) {
    aiDetails.classList.remove("hidden");
  } else {
    aiDetails.classList.add("hidden");
  }
  document.getElementById("ai-toggle-details").addEventListener("click", (e) => {
    e.preventDefault();
    aiDetails.classList.toggle("hidden");
  });
  aiEnhanceCheckbox.addEventListener("change", (e) => {
    const checked = e.target.checked;
    if (checked) {
      aiDetails.classList.remove("hidden");
    } else {
      aiDetails.classList.add("hidden");
    }
    void setConfig({ aiEnhanceEnabled: checked });
  });
  const toggleAdvanced = document.getElementById("toggle-advanced");
  const advancedContent = document.getElementById("advanced-content");
  toggleAdvanced.addEventListener("click", () => {
    advancedContent.classList.toggle("hidden");
    toggleAdvanced.classList.toggle("expanded");
  });
  imageLocCheckbox.addEventListener("change", () => {
    void setConfig({ imageLocalization: imageLocCheckbox.checked });
  });
  quickCaptureCheckbox.addEventListener("change", () => {
    void setConfig({ quickCapture: quickCaptureCheckbox.checked });
  });
  aiModeSelect.addEventListener("change", () => {
    void setConfig({ aiEnhanceMode: aiModeSelect.value });
  });
  document.querySelectorAll("#ai-details input[data-task]").forEach((el) => {
    el.addEventListener("change", () => {
      const tasks = collectAITasks();
      void setConfig({ aiEnhanceTasks: tasks });
    });
  });
  const triggerConnectionCheck = () => {
    if (checkTimeout) clearTimeout(checkTimeout);
    checkTimeout = setTimeout(() => {
      const serverUrl = serverInput.value.trim();
      const token = tokenInput.value.trim();
      void checkConnection(serverUrl, token);
    }, 500);
  };
  serverInput.addEventListener("input", triggerConnectionCheck);
  tokenInput.addEventListener("input", triggerConnectionCheck);
  document.getElementById("clip-article").addEventListener("click", () => clip("article"));
  document.getElementById("clip-selection").addEventListener("click", () => clip("selection"));
  document.getElementById("clip-more").addEventListener("click", () => {
    const mode = document.getElementById("clip-mode").value;
    void clip(mode);
  });
  if (cfg.serverUrl && cfg.token) {
    await checkConnection(cfg.serverUrl, cfg.token);
  } else {
    disableClipUI();
  }
}
function collectAITasks() {
  const tasks = {};
  document.querySelectorAll("#ai-details input[data-task]").forEach((el) => {
    const k = el.dataset.task;
    if (el.checked) tasks[k] = true;
  });
  return tasks;
}
async function checkConnection(serverUrl, token) {
  const badge = document.getElementById("connection-badge");
  if (!serverUrl || !token) {
    badge.className = "badge err";
    badge.textContent = "❌ 未连接";
    disableClipUI();
    return;
  }
  badge.className = "badge warn";
  badge.textContent = "⏳ 连接中...";
  try {
    const tempCfg = { serverUrl, token };
    const r = await ping(tempCfg);
    badge.className = "badge ok";
    badge.textContent = `✅ 连接正常 (${r.username})`;
    await setConfig({ serverUrl, token });
    enableClipUI();
    await loadWorkspacesAndNotebooks();
  } catch (err) {
    badge.className = "badge err";
    badge.textContent = "❌ 连接失败";
    disableClipUI();
  }
}
function enableClipUI() {
  document.getElementById("clip-settings-panel").classList.remove("disabled");
  document.getElementById("advanced-panel").classList.remove("disabled");
  document.getElementById("more-actions-row").classList.remove("disabled");
  document.getElementById("workspace-select").disabled = false;
  document.getElementById("notebook-select").disabled = false;
  document.getElementById("clip-article").disabled = false;
  document.getElementById("clip-selection").disabled = false;
  document.getElementById("clip-more").disabled = false;
  document.getElementById("clip-mode").disabled = false;
}
function disableClipUI() {
  document.getElementById("clip-settings-panel").classList.add("disabled");
  document.getElementById("advanced-panel").classList.add("disabled");
  document.getElementById("more-actions-row").classList.add("disabled");
  document.getElementById("workspace-select").disabled = true;
  document.getElementById("notebook-select").disabled = true;
  document.getElementById("clip-article").disabled = true;
  document.getElementById("clip-selection").disabled = true;
  document.getElementById("clip-more").disabled = true;
  document.getElementById("clip-mode").disabled = true;
}
async function loadWorkspacesAndNotebooks() {
  const cfg = await getConfig();
  const wsSelect = document.getElementById("workspace-select");
  const savedWsId = cfg.lastWorkspaceId || "personal";
  try {
    const workspaces = await getClipWorkspaces(cfg);
    wsSelect.innerHTML = `<option value="personal">个人空间</option>`;
    for (const ws of workspaces) {
      const opt = document.createElement("option");
      opt.value = ws.id;
      opt.textContent = ws.name;
      wsSelect.appendChild(opt);
    }
    wsSelect.value = savedWsId;
    if (wsSelect.value !== savedWsId) {
      wsSelect.value = "personal";
    }
    wsSelect.onchange = async () => {
      const val = wsSelect.value;
      await setConfig({ lastWorkspaceId: val });
      await loadNotebooksForWorkspace(val);
    };
    await loadNotebooksForWorkspace(wsSelect.value);
  } catch (err) {
    console.error("加载工作区失败:", err);
  }
}
async function loadNotebooksForWorkspace(workspaceId) {
  const cfg = await getConfig();
  const nbSelect = document.getElementById("notebook-select");
  const savedNbId = cfg.lastNotebookId || "__default__";
  try {
    const wsVal = workspaceId === "personal" ? void 0 : workspaceId;
    const notebooks = await getClipNotebooks(cfg, wsVal);
    nbSelect.innerHTML = `
      <option value="__default__">📓 默认：剪藏笔记本</option>
      <option value="__diary__">💬 保存为说说</option>
    `;
    for (const nb of notebooks) {
      const opt = document.createElement("option");
      opt.value = nb.id;
      opt.textContent = nb.name;
      nbSelect.appendChild(opt);
    }
    nbSelect.value = savedNbId;
    if (nbSelect.value !== savedNbId) {
      nbSelect.value = "__default__";
    }
    nbSelect.onchange = async () => {
      await setConfig({ lastNotebookId: nbSelect.value });
    };
  } catch (err) {
    console.error("加载笔记本失败:", err);
  }
}
async function clip(mode) {
  const progress = document.getElementById("progress");
  const progressText = document.getElementById("progress-text");
  const resultEl = document.getElementById("result");
  resultEl.classList.add("hidden");
  progress.classList.remove("hidden");
  progressText.textContent = "准备中...";
  disableClipUI();
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) {
    showResult(false, "未找到当前标签页");
    enableClipUI();
    progress.classList.add("hidden");
    return;
  }
  const comment = document.getElementById("comment").value.trim();
  const aiEnhance = document.getElementById("ai-enhance").checked;
  const aiMode = document.getElementById("ai-mode").value;
  const aiTasks = collectAITasks();
  try {
    await setConfig({
      aiEnhanceEnabled: aiEnhance,
      aiEnhanceMode: aiMode,
      aiEnhanceTasks: aiTasks
    });
  } catch {
  }
  const workspaceSelect = document.getElementById("workspace-select");
  const notebookSelect = document.getElementById("notebook-select");
  const workspaceId = workspaceSelect.value;
  const notebookId = notebookSelect.value;
  const req = {
    type: "CLIP_REQUEST",
    mode,
    tabId: tab.id,
    overrideTags: document.getElementById("tags").value.trim(),
    workspaceId: workspaceId || void 0,
    notebookId: notebookId || void 0,
    comment: comment || void 0,
    aiEnhance,
    aiTasks,
    aiMode
  };
  if (mode === "screenshot" || mode === "fullScreenshot") {
    progressText.textContent = "正在准备截图，popup 即将关闭...";
    chrome.runtime.sendMessage(req).catch(() => {
    });
    setTimeout(() => window.close(), 100);
    return;
  }
  const handler = (msg) => {
    if (msg?.type !== "CLIP_PROGRESS") return;
    progressText.textContent = msg.message;
  };
  chrome.runtime.onMessage.addListener(handler);
  try {
    const res = await chrome.runtime.sendMessage(req);
    progress.classList.add("hidden");
    if (res?.ok) {
      const imgInfo = res.images ? `图片 ${res.images.ok} 张${res.images.failed ? `（${res.images.failed} 张失败）` : ""}` : "";
      showResult(true, `✅ 已剪藏：「${res.noteTitle || "无标题"}」${imgInfo ? "，" + imgInfo : ""}`);
    } else {
      showResult(false, `❌ ${res?.error || "未知错误"}`);
    }
  } catch (e) {
    progress.classList.add("hidden");
    showResult(false, `❌ ${String(e?.message || e)}`);
  } finally {
    chrome.runtime.onMessage.removeListener(handler);
    enableClipUI();
  }
}
function showResult(ok, text) {
  const el = document.getElementById("result");
  el.classList.remove("hidden", "ok", "err");
  el.classList.add(ok ? "ok" : "err");
  el.textContent = text;
}
void init();
