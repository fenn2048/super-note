const DEFAULTS = {
  serverUrl: "",
  username: "",
  token: "",
  displayName: "",
  defaultNotebook: "Web 剪藏",
  defaultTags: "",
  imageMode: "inline",
  imageLocalization: true,
  includeSource: true,
  outputFormat: "markdown",
  quickCapture: false,
  quickCaptureMode: "article",
  // AI 默认行为：默认关闭，主动开启；开启后默认做"摘要 + 标签"两项最稳的
  aiEnhanceEnabled: false,
  aiEnhanceTasks: {
    summary: true,
    tags: true,
    outline: false,
    title: false,
    highlight: false,
    translation: false
  },
  aiEnhanceMode: "prepend",
  aiEnhanceLanguage: "zh-CN",
  aiCustomInstruction: "",
  aiMaxInputChars: 6e3,
  aiFailureStrategy: "fallback",
  lastWorkspaceId: "personal",
  lastNotebookId: "__default__"
};
const CONFIG_KEY = "nowenClipperConfig";
async function getConfig() {
  const store = chrome.storage.sync || chrome.storage.local;
  const data = await store.get(CONFIG_KEY);
  const raw = data[CONFIG_KEY] || {};
  const merged = { ...DEFAULTS, ...raw };
  if (raw.aiEnhanceTasks) {
    merged.aiEnhanceTasks = { ...DEFAULTS.aiEnhanceTasks, ...raw.aiEnhanceTasks };
  }
  return merged;
}
async function setConfig(patch) {
  const current = await getConfig();
  const merged = { ...current, ...patch };
  const store = chrome.storage.sync || chrome.storage.local;
  await store.set({ [CONFIG_KEY]: merged });
  return merged;
}
function isConfigured(cfg) {
  return !!cfg.serverUrl && !!cfg.token;
}
function normalizeBaseUrl(url) {
  return url.trim().replace(/\/+$/, "");
}
class NowenApiError extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
    this.name = "NowenApiError";
  }
}
function authHeaders(cfg) {
  return {
    Authorization: `Bearer ${cfg.token}`,
    "Content-Type": "application/json"
  };
}
async function parseErr(res) {
  let code;
  let message = res.statusText;
  try {
    const data = await res.json();
    code = data.code;
    if (data.error) message = data.error;
  } catch {
    try {
      message = await res.text() || message;
    } catch {
    }
  }
  return new NowenApiError(res.status, code, `[${res.status}] ${message}`);
}
async function login(serverUrl, username, password) {
  const base = normalizeBaseUrl(serverUrl);
  const res = await fetch(`${base}/api/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, password })
  });
  if (!res.ok) throw await parseErr(res);
  return await res.json();
}
async function verify2FA(serverUrl, ticket, code) {
  const base = normalizeBaseUrl(serverUrl);
  const res = await fetch(`${base}/api/auth/2fa/verify`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ticket, code })
  });
  if (!res.ok) throw await parseErr(res);
  return await res.json();
}
async function ping(cfg) {
  const base = normalizeBaseUrl(cfg.serverUrl);
  const res = await fetch(`${base}/api/me`, {
    method: "GET",
    headers: authHeaders(cfg)
  });
  if (!res.ok) throw await parseErr(res);
  return await res.json();
}
async function enhanceClip(cfg, payload) {
  const base = normalizeBaseUrl(cfg.serverUrl);
  const res = await fetch(`${base}/api/ai/clip-enhance`, {
    method: "POST",
    headers: authHeaders(cfg),
    body: JSON.stringify(payload)
  });
  if (!res.ok) throw await parseErr(res);
  return await res.json();
}
async function getClipWorkspaces(cfg) {
  const base = normalizeBaseUrl(cfg.serverUrl);
  const res = await fetch(`${base}/api/clip/workspaces`, {
    method: "GET",
    headers: {
      Authorization: `Bearer ${cfg.token}`
    }
  });
  if (!res.ok) throw await parseErr(res);
  return await res.json();
}
async function getClipNotebooks(cfg, workspaceId) {
  const base = normalizeBaseUrl(cfg.serverUrl);
  const url = workspaceId ? `${base}/api/clip/notebooks?workspaceId=${encodeURIComponent(workspaceId)}` : `${base}/api/clip/notebooks`;
  const res = await fetch(url, {
    method: "GET",
    headers: {
      Authorization: `Bearer ${cfg.token}`
    }
  });
  if (!res.ok) throw await parseErr(res);
  return await res.json();
}
async function uploadClipImage(cfg, file, workspaceId) {
  const base = normalizeBaseUrl(cfg.serverUrl);
  const url = workspaceId ? `${base}/api/clip/upload-img?workspaceId=${encodeURIComponent(workspaceId)}` : `${base}/api/clip/upload-img`;
  const formData = new FormData();
  formData.append("file", file);
  const res = await fetch(url, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${cfg.token}`
    },
    body: formData
  });
  if (!res.ok) throw await parseErr(res);
  return await res.json();
}
async function saveClip(cfg, payload) {
  const base = normalizeBaseUrl(cfg.serverUrl);
  const res = await fetch(`${base}/api/clip/save`, {
    method: "POST",
    headers: authHeaders(cfg),
    body: JSON.stringify(payload)
  });
  if (!res.ok) throw await parseErr(res);
  return await res.json();
}
export {
  NowenApiError as N,
  setConfig as a,
  getClipWorkspaces as b,
  getClipNotebooks as c,
  enhanceClip as e,
  getConfig as g,
  isConfigured as i,
  login as l,
  normalizeBaseUrl as n,
  ping as p,
  saveClip as s,
  uploadClipImage as u,
  verify2FA as v
};
