const DEFAULTS = {
  serverUrl: "",
  username: "",
  token: "",
  displayName: "",
  defaultNotebook: "剪藏笔记",
  defaultTags: "",
  imageMode: "inline",
  imageLocalization: true,
  includeSource: true,
  outputFormat: "markdown",
  quickCapture: false,
  quickCaptureMode: "article",
  aiEnhanceEnabled: false,
  aiEnhanceTasks: {
    summary: true,
    tags: true,
    outline: false,
    title: false,
    highlight: false,
    translation: false
  },
  aiEnhanceMode: "prepend",
  aiEnhanceLanguage: "zh-CN",
  aiCustomInstruction: "",
  aiMaxInputChars: 6e3,
  aiFailureStrategy: "fallback",
  lastWorkspaceId: "",
  lastNotebookId: "__default__",
  authMethod: "token"
};
const CONFIG_KEY = "superClipperConfig";
const HISTORY_KEY = "superClipperHistory";
const HISTORY_MAX = 8;
function migrateConfig(raw) {
  const merged = { ...DEFAULTS, ...raw };
  if (raw.aiEnhanceTasks) {
    merged.aiEnhanceTasks = { ...DEFAULTS.aiEnhanceTasks, ...raw.aiEnhanceTasks };
  }
  if (merged.lastWorkspaceId === "personal" || merged.lastWorkspaceId === "undefined") {
    merged.lastWorkspaceId = "";
  }
  if (merged.defaultNotebook === "Web 剪藏") {
    merged.defaultNotebook = "剪藏笔记";
  }
  if (!merged.authMethod) {
    merged.authMethod = merged.token?.startsWith("nkn_") ? "token" : "login";
  }
  return merged;
}
async function getConfig() {
  const store = chrome.storage.sync || chrome.storage.local;
  const data = await store.get(CONFIG_KEY);
  const raw = data[CONFIG_KEY] || {};
  return migrateConfig(raw);
}
async function setConfig(patch) {
  const current = await getConfig();
  const merged = migrateConfig({ ...current, ...patch });
  const store = chrome.storage.sync || chrome.storage.local;
  await store.set({ [CONFIG_KEY]: merged });
  return merged;
}
function isConfigured(cfg) {
  return !!cfg.serverUrl?.trim() && !!cfg.token?.trim();
}
function normalizeBaseUrl(url) {
  let cleaned = url.trim().replace(/\/+$/, "");
  if (cleaned && !/^https?:\/\//i.test(cleaned)) {
    cleaned = "http://" + cleaned;
  }
  return cleaned;
}
function noteOpenUrl(serverUrl, noteId) {
  const base = normalizeBaseUrl(serverUrl);
  if (noteId) {
    return `${base}/#/notes?clipNoteId=${encodeURIComponent(noteId)}`;
  }
  return `${base}/#/notes`;
}
async function getClipHistory() {
  try {
    const data = await chrome.storage.local.get(HISTORY_KEY);
    const list = data[HISTORY_KEY];
    return Array.isArray(list) ? list : [];
  } catch {
    return [];
  }
}
async function pushClipHistory(item) {
  const prev = await getClipHistory();
  const next = {
    id: item.id || `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    title: item.title || "无标题",
    noteId: item.noteId,
    ok: item.ok,
    error: item.error,
    at: item.at || Date.now()
  };
  const list = [next, ...prev].slice(0, HISTORY_MAX);
  await chrome.storage.local.set({ [HISTORY_KEY]: list });
}
class SuperApiError extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
    this.name = "SuperApiError";
  }
}
function authHeaders(cfg) {
  return {
    Authorization: `Bearer ${cfg.token}`,
    "Content-Type": "application/json"
  };
}
async function parseErr(res) {
  let code;
  let message = res.statusText;
  try {
    const data = await res.json();
    code = data.code;
    if (data.error) message = data.error;
  } catch {
    try {
      message = await res.text() || message;
    } catch {
    }
  }
  return new SuperApiError(res.status, code, `[${res.status}] ${message}`);
}
async function login(serverUrl, username, password) {
  const base = normalizeBaseUrl(serverUrl);
  const res = await fetch(`${base}/api/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, password })
  });
  if (!res.ok) throw await parseErr(res);
  return await res.json();
}
async function verify2FA(serverUrl, ticket, code) {
  const base = normalizeBaseUrl(serverUrl);
  const res = await fetch(`${base}/api/auth/2fa/verify`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ticket, code })
  });
  if (!res.ok) throw await parseErr(res);
  return await res.json();
}
async function ping(cfg) {
  const base = normalizeBaseUrl(cfg.serverUrl);
  const res = await fetch(`${base}/api/me`, {
    method: "GET",
    headers: authHeaders(cfg)
  });
  if (!res.ok) throw await parseErr(res);
  return await res.json();
}
async function enhanceClip(cfg, payload, opts) {
  const base = normalizeBaseUrl(cfg.serverUrl);
  const timeoutMs = opts?.timeoutMs;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(`${base}/api/ai/clip-enhance`, {
      method: "POST",
      headers: authHeaders(cfg),
      body: JSON.stringify(payload),
      signal: ctrl.signal
    });
    if (!res.ok) throw await parseErr(res);
    return await res.json();
  } catch (e) {
    if (e?.name === "AbortError") {
      return { ok: false, error: `AI 超时（>${Math.round(timeoutMs / 1e3)}s）` };
    }
    throw e;
  } finally {
    clearTimeout(timer);
  }
}
async function getClipWorkspaces(cfg) {
  const base = normalizeBaseUrl(cfg.serverUrl);
  const res = await fetch(`${base}/api/clip/workspaces`, {
    method: "GET",
    headers: {
      Authorization: `Bearer ${cfg.token}`
    }
  });
  if (!res.ok) throw await parseErr(res);
  return await res.json();
}
async function getClipNotebooks(cfg, workspaceId) {
  const base = normalizeBaseUrl(cfg.serverUrl);
  const url = workspaceId ? `${base}/api/clip/notebooks?workspaceId=${encodeURIComponent(workspaceId)}` : `${base}/api/clip/notebooks`;
  const res = await fetch(url, {
    method: "GET",
    headers: {
      Authorization: `Bearer ${cfg.token}`
    }
  });
  if (!res.ok) throw await parseErr(res);
  return await res.json();
}
async function uploadClipImage(cfg, file, workspaceId) {
  const base = normalizeBaseUrl(cfg.serverUrl);
  const url = workspaceId ? `${base}/api/clip/upload-img?workspaceId=${encodeURIComponent(workspaceId)}` : `${base}/api/clip/upload-img`;
  const formData = new FormData();
  formData.append("file", file);
  const res = await fetch(url, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${cfg.token}`
    },
    body: formData
  });
  if (!res.ok) throw await parseErr(res);
  return await res.json();
}
async function saveClip(cfg, payload) {
  const base = normalizeBaseUrl(cfg.serverUrl);
  const res = await fetch(`${base}/api/clip/save`, {
    method: "POST",
    headers: authHeaders(cfg),
    body: JSON.stringify(payload)
  });
  if (!res.ok) throw await parseErr(res);
  return await res.json();
}
export {
  SuperApiError as S,
  setConfig as a,
  getClipHistory as b,
  normalizeBaseUrl as c,
  ping as d,
  enhanceClip as e,
  getClipWorkspaces as f,
  getConfig as g,
  getClipNotebooks as h,
  isConfigured as i,
  login as l,
  noteOpenUrl as n,
  pushClipHistory as p,
  saveClip as s,
  uploadClipImage as u,
  verify2FA as v
};
